<?php
include "config.php";


$std_id = $_POST['std_id'];
$sql_statement = "DELETE FROM Departments WHERE student_id = '$student_id'";
$result = mysqli_query($db, $sql_statement);
header ("Location: index.php");
?>