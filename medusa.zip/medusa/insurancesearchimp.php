<!DOCTYPE html>
<html>
<head>
	<title></title>

<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>

</head>
<h1 style="color:white; font-family:calibri; ">M.E.D.U.S.A</h1>
<body style = "background-color: darkolivegreen; text-align: center;">

<div align="center">

	<table>

<tr> <th> Company Name </th> </tr> 


<?php

include "config.php";

$company_name2 = $_POST['company_name'];

$sql_statement = "SELECT * FROM insurance WHERE company_name = '$company_name2'";

$result = mysqli_query($db, $sql_statement);

while($row = mysqli_fetch_assoc($result))
{
  $company_name = $row['company_name'];
	echo "<tr>" . "<th>" . $company_name . "</th>". "</tr>";
}

?>

</table>
<a style="color:white; font-family:calibri;" href = "http://localhost/medusa/">Return to main menu</a>
</div>

</body>
</html>