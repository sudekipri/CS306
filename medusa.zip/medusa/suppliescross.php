<?php 

include "config.php";

$selection_id = $_POST['ids'];

if($selection_id == 1){header ("Location: suppliesinsert.php");}
if($selection_id == 2){header ("Location: suppliesdelete.php");}
if($selection_id == 3){header ("Location: suppliesprint.php");}
if($selection_id == 4){header ("Location: suppliessearch.php");}

?>