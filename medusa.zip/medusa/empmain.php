<?php
include "config.php";

?>

<h1 style="color:white; font-family:calibri; ">M.E.D.U.S.A</h1>
<body style = "background-color: darkolivegreen; text-align: center;">

<h2 style="color:white; font-family:calibri; ">Please select an action for the 'Employees' table</h2>

<form action="empcross.php" method="POST">
<select name="ids">

<option value=1>Insert</option>
<option value=2>Delete</option>
<option value=3>Print</option>
<option value=4>Search by ID</option>
<option value=5>Search by employee ID and see his/her medical reports and department</option>
</select>

<button>Go</button>
</form>
<a style="color:white; font-family:calibri;" href = "http://localhost/medusa/">Return to main menu</a>
</body>