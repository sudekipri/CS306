<?php
include "config.php";


$work_id = $_POST['work_id'];
$dep_id = $_POST['dep_id'];

$sql_statement = "DELETE FROM WorksIn WHERE work_id = '$work_id'and dep_id = '$dep_id'";

$result = mysqli_query($db, $sql_statement);
header ("Location: index.php");
?>