<?php
include "config.php";


$work_id = $_POST['work_id'];
$emp_name = $_POST['emp_name'];
$emp_age = $_POST['emp_age'];
$emp_sex = $_POST['emp_sex'];
$position = $_POST['position'];
$emp_salary = $_POST['emp_salary'];
$sql_statement = "INSERT INTO employees(work_id, emp_name, emp_age, emp_sex, position, emp_salary) VALUES ('$work_id', '$emp_name', '$emp_age', '$emp_sex', '$position', '$emp_salary')";
$result = mysqli_query($db, $sql_statement);
header ("Location: index.php");
?>