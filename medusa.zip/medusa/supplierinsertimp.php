<?php
include "config.php";

$supplier_name = $_POST['supplier_name'];
$supply_name = $_POST['supply_name'];
$supply_date = $_POST['supply_date'];
$quantity = $_POST['quantity'];
$unit_price = $_POST['unit_price'];
$sql_statement = "INSERT INTO suppliers(supplier_name, supply_name, supply_date, quantity, unit_price) VALUES ('$supplier_name', '$supply_name', '$supply_date', '$quantity', '$unit_price')";
$result = mysqli_query($db, $sql_statement);
header ("Location: index.php");
?>