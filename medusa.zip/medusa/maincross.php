<?php 

include "config.php";

$selection_id = $_POST['ids'];

if($selection_id == 1){header ("Location: empmain.php");}
if($selection_id == 2){header ("Location: patientsmain.php");}
if($selection_id == 3){header ("Location: medrepmain.php");}
if($selection_id == 4){header ("Location: studentmain.php");}
if($selection_id == 5){header ("Location: depmain.php");}
if($selection_id == 6){header ("Location: suppliermain.php");}
if($selection_id == 7){header ("Location: insurancemain.php");}
if($selection_id == 8){header ("Location: treatsmain.php");}
if($selection_id == 9){header ("Location: coversmain.php");}
if($selection_id == 10){header ("Location: hasmain.php");}
if($selection_id == 11){header ("Location: writesmain.php");}
if($selection_id == 12){header ("Location: tutorsmain.php");}
if($selection_id == 13){header ("Location: worksinmain.php");}
if($selection_id == 14){header ("Location: suppliesmain.php");}




?>