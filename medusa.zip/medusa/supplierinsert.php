<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<h1 style="color:white; font-family:calibri; ">M.E.D.U.S.A</h1>
<body style = "background-color: darkolivegreen; text-align: center;">

	<h2 style="color:white; font-family:calibri; ">Please enter the information to create a new supplier</h2>

<form
	action="supplierinsertimp.php" method="POST">
	<h2 style="color:white; font-family:calibri; ">Supplier Name: <input type="text" id="fsupplier_name" name="supplier_name"> </h2>
	
	<h2 style="color:white; font-family:calibri; ">Supply Name: <input type="text" id="fsupply_name" name="supply_name"> </h2>
	
	<h2 style="color:white; font-family:calibri; ">Supply Date: <input type="text" id="fsupply_date" name= "supply_date"> </h2>
	
	<h2 style="color:white; font-family:calibri; ">Quantity: <input type="number" id="fquantity" name="quantity"> </h2>
	
	<h2 style="color:white; font-family:calibri; ">Unit Price: <input type="number" id="funit_price" name="unit_price"> </h2>
	
	<input type="submit" value="Submit">
</form>
<a style="color:white; font-family:calibri;" href = "http://localhost/medusa/">Return to main menu</a>
</body>
</html>
