<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<h1 style="color:white; font-family:calibri; ">M.E.D.U.S.A</h1>
<body style = "background-color: darkolivegreen; text-align: center;">
	<h2 style="color:white; font-family:calibri; ">Please enter information to create an insurance record</h2>
<form
	action="coversinsertimp.php" method="POST">
	<h3 style="color:white; font-family:calibri; ">Patient ID: <input type="number" id="fpatient_id" name="patient_id"> </h3>
	
	<h3 style="color:white; font-family:calibri; ">Covered Expenses: <input type="number" id="fcovered_expenses" name="covered_expenses"> </h3>
	
	<h3 style="color:white; font-family:calibri; ">Company Name <input type="text" id="f company_name" name= "company_name"> </h3>
	
	<input type="submit" value="Submit">
</form>
<a style="color:white; font-family:calibri;" href = "http://localhost/medusa/">Return to main menu</a>
</body>
</html>