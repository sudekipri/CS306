<!DOCTYPE html>
<html>
<head>
	<title></title>

<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>

</head>
<h1 style="color:white; font-family:calibri; ">M.E.D.U.S.A</h1>
<body style = "background-color: darkolivegreen; text-align: center;">

<h2 style="color:white; font-family:calibri; ">Details of the supplier are shown below</h2>

<div align="center">

	<table>

<tr> <th> Supplier Name </th> <th> Supply Name </th> <th>Supply Date</th> <th>Quantity</th> <th>Unit Price</th> </tr> 


<?php

include "config.php";

$supplier_name2 = $_POST['supplier_name'];

$sql_statement = "SELECT * FROM suppliers WHERE supplier_name = '$supplier_name2'";

$result = mysqli_query($db, $sql_statement);

while($row = mysqli_fetch_assoc($result))
{
  $supplier_name = $row['supplier_name'];
  $supply_name = $row['supply_name'];
	$supply_date = $row['supply_date'];
	$quantity = $row['quantity'];
	$unit_price = $row['unit_price'];
	echo "<tr>" . "<th>" . $supplier_name . "</th>" . "<th>" . $supply_name . "</th>" . "<th>" . $supply_date . "</th>" . "<th>" . $quantity . "</th>" . "<th>" . $unit_price . "</th>" . "</tr>";
}

?>

</table>
<a style="color:white; font-family:calibri;" href = "http://localhost/medusa/">Return to main menu</a>
</div>

</body>
</html>