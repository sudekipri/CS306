<!DOCTYPE html>
<html>
<head>
	<title></title>

<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>

</head>
<h1 style="color:white; font-family:calibri; ">M.E.D.U.S.A</h1>
<body style = "background-color: darkolivegreen; text-align: center;">

	

<div align="center">

	<table>

<tr> <th> Patient ID </th> <th> Work ID </th> </tr > 


<?php

	include "config.php";

$patient_id2 = $_POST['patient_id'];

$sql_statement = "SELECT * FROM treats WHERE patient_id = '$patient_id2'";

$result = mysqli_query($db, $sql_statement);

while ($row = mysqli_fetch_assoc($result))
{
	$patient_id = $row['patient_id'];
	$work_id = $row['work_id'];


	echo "<tr>" . "<th>".$patient_id . "</th>" . "<th>".$work_id . "</th>" . "<th>";
}

?>

</table>
<a style="color:white; font-family:calibri;" href = "http://localhost/medusa/">Return to main menu</a>
</div>

</body>
</html>