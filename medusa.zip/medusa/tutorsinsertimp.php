<?php
include "config.php";


$work_id = $_POST['work_id'];
$student_id = $_POST['student_id'];
$sql_statement = "INSERT INTO tutors (work_id, student_id) VALUES ('$work_id', '$student_id')";
$result = mysqli_query($db, $sql_statement);
header ("Location: index.php");
?>