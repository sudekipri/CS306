<?php
include "config.php";

$supplier_name = $_POST['supplier_name'];
$sql_statement = "DELETE FROM suppliers WHERE supplier_name = '$supplier_name'";
$result = mysqli_query($db, $sql_statement);
header ("Location: index.php");
?>