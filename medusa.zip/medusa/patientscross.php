<?php 

include "config.php";

$selection_id = $_POST['ids'];

if($selection_id == 1){header ("Location: patientsinsert.php");}
if($selection_id == 2){header ("Location: patientsdelete.php");}
if($selection_id == 3){header ("Location: patientsprint.php");}
if($selection_id == 4){header ("Location: patientssearch.php");}
if($selection_id == 5){header ("Location: patientmedsearch.php");}

?>