<?php 

include "config.php";

$selection_id = $_POST['ids'];

if($selection_id == 1){header ("Location: writesinsert.php");}
if($selection_id == 2){header ("Location: writesdelete.php");}
if($selection_id == 3){header ("Location: writesprint.php");}
if($selection_id == 4){header ("Location: writessearch.php");}

?>