<!DOCTYPE html>
<html>
<head>
	<title></title>

<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>

</head>
<h1 style="color:white; font-family:calibri; ">M.E.D.U.S.A</h1>
<body style = "background-color: darkolivegreen; text-align: center;">

	<h2 style="color:white; font-family:calibri; ">Details of the medical report are shown below</h2>

<div align="center">

	<table>

<tr> <th> Report No </th> <th> Date </th> <th> Medication </th> <th> Treatment </th> <th> Bill </th> </tr> 


<?php

include "config.php";

$report_no2 = $_POST['report_no'];

$sql_statement = "SELECT * FROM medical_reports WHERE report_no = '$report_no2'";

$result = mysqli_query($db, $sql_statement);

while($row = mysqli_fetch_assoc($result))
{
  $report_no = $row['report_no'];
  $date = $row['date'];
	$medication = $row['medication'];
	$treatment = $row['treatment'];
	$bill = $row['bill'];

	echo "<tr>" . "<th>" . $report_no . "</th>" . "<th>" . $date . "</th>" . "<th>" . $medication . "</th>" . "<th>" . $treatment . "</th>" . "<th>" . $bill . "</th>" . "</tr>";
}

?>

</table>
<a style="color:white; font-family:calibri;" href = "http://localhost/medusa/">Return to main menu</a>
</div>

</body>
</html>