<?php
	include "config.php";


$raport_no = $_POST['raport_no'];
$sql_statement = "DELETE FROM medical_reports WHERE report_no = '$raport_no'";
$result = mysqli_query($db, $sql_statement);
header("Location: index.php");
?>