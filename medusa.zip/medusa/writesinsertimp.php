<?php
	include "config.php";

$work_id = $_POST['work_id'];
$report_no = $_POST['report_no'];

$sql_statement = "INSERT INTO writes(work_id, report_no) VALUES ('$work_id', '$report_no')";
$result = mysqli_query($db, $sql_statement);
header("Location: index.php");
?>