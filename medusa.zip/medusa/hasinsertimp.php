<?php
include "config.php";

$patient_id = $_POST['patient_id'];
$report_no = $_POST['report_no'];
$sql_statement = "INSERT INTO has(patient_id, report_no) VALUES ('$patient_id', '$report_no')";
$result = mysqli_query($db, $sql_statement);
header ("Location: index.php");
?>