<?php
include "config.php";

?>

<h1 style="color:white; font-family:calibri; ">M.E.D.U.S.A</h1>
<body style = "background-color: darkolivegreen; text-align: center;">

<h2 style="color:white; font-family:calibri; ">Welcome! Please select a table to work on</h2>

<form action="maincross.php" method="POST">
<select name="ids">

<option value=1>Employees</option>
<option value=2>Patients</option>
<option value=3>Medical Records</option>
<option value=4>Students</option>
<option value=5>Departments</option>
<option value=6>Suppliers</option>
<option value=7>Insurance</option>
<option value=8>Treats</option>
<option value=9>Covers</option>
<option value=10>Has</option>
<option value=11>Writes</option>
<option value=12>Tutors</option>
<option value=13>Works in</option>
<option value=14>Supplies</option>
</select>

<button>Go</button>
</form>
</body>