<?php 

include "config.php";

$selection_id = $_POST['ids'];

if($selection_id == 1){header ("Location: coversinsert.php");}
if($selection_id == 2){header ("Location: coversdelete.php");}
if($selection_id == 3){header ("Location: coversprint.php");}
if($selection_id == 4){header ("Location: coverssearch.php");}

?>