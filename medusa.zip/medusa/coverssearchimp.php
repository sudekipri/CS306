<!DOCTYPE html>
<html>
<head>
	<title></title>

<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>

</head>
<h1 style="color:white; font-family:calibri; ">M.E.D.U.S.A</h1>
<body style = "background-color: darkolivegreen; text-align: center;">

<h2 style="color:white; font-family:calibri; ">Insurance record of the patient is shown below</h2>

<div align="center">

	<table>

<tr> <th> Patient ID </th> <th> Covered Expenses </th> <th>Company Name</th> </tr> 


<?php

include "config.php";

$patient_id2 = $_POST['patient_id'];

$sql_statement = "SELECT * FROM covers WHERE patient_id = '$patient_id2'";

$result = mysqli_query($db, $sql_statement);

while($row = mysqli_fetch_assoc($result))
{
  $patient_id = $row['patient_id'];
  $covered_expenses = $row['covered_expenses'];
	$company_name = $row['company_name'];
	echo "<tr>" . "<th>" . $patient_id . "</th>" . "<th>" . $covered_expenses . "</th>" . "<th>" . $company_name . "</th>". "</tr>";
}

?>

</table>
<a style="color:white; font-family:calibri;" href = "http://localhost/medusa/">Return to main menu</a>
</div>

</body>
</html>