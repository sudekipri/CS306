<?php
include "config.php";


$work_id = $_POST['work_id'];
$sql_statement = "DELETE FROM employees WHERE work_id = '$work_id'";
$result = mysqli_query($db, $sql_statement);
header ("Location: index.php");
?>