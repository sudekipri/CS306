<?php
include "config.php";

$patient_id = $_POST['patient_id'];
$covered_expenses = $_POST['covered_expenses'];
$company_name = $_POST['company_name'];
$sql_statement = "INSERT INTO covers(patient_id, covered_expenses, company_name) VALUES ('$patient_id', '$covered_expenses', '$company_name')";
$result = mysqli_query($db, $sql_statement);
header ("Location: index.php");
?>