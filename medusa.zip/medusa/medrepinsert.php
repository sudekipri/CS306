<!DOCTYPE html>
<html>
<head>
<meta charset = "utf-8">
<meta name = "viewport" content = "width=device-width, initial-scale=1">
<title></title>
</head>
<h1 style="color:white; font-family:calibri; ">M.E.D.U.S.A</h1>
<body style = "background-color: darkolivegreen; text-align: center;">
<h2 style="color:white; font-family:calibri; ">Please enter the information to create a new medical report</h2>
<form
	action = "medrepinsertimp.php" method = "POST">
	<h2 style="color:white; font-family:calibri; ">Report No: <input type = "number" id = "fraport_no" name = "raport_no"> </h2>
	
	<h2 style="color:white; font-family:calibri; ">Date: <input type = "text" id = "fdate" name = "date"> </h2>
	
	<h2 style="color:white; font-family:calibri; ">Medication: <input type = "text" id = "fmedication" name = "medication"> </h2>
	
	<h2 style="color:white; font-family:calibri; ">Treatment: <input type = "text" id = "ftreatment" name = "treatment"> </h2>
	
	<h2 style="color:white; font-family:calibri; ">Bill: <input type = "number" id = "fbill" name = "bill"> </h2>
	
	<input type = "submit" value = "Submit">
	</form>
	<a style="color:white; font-family:calibri;" href = "http://localhost/medusa/">Return to main menu</a>
	</body>
	</html>