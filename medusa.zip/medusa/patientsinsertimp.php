<?php
include "config.php";


$patient_id = $_POST['patient_id'];
$patient_name = $_POST['patient_name'];
$patient_age = $_POST['emp_age'];
$patient_sex = $_POST['patient_sex'];
$emergency_contact = $_POST['emergency_contact'];
$sql_statement = "INSERT INTO patients(patient_id, patient_name, patient_age, patient_sex, emergency_contact) VALUES ('$patient_id', '$patient_name', '$patient_age', '$patient_sex','$emergency_contact')";
$result = mysqli_query($db, $sql_statement);
header("Location: index.php");
?>