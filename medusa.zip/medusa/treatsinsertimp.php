<?php
	include "config.php";


$patient_id = $_POST['patient_id'];
$work_id = $_POST['work_id'];
$sql_statement = "INSERT INTO treats(patient_id, work_id) VALUES ('$patient_id', '$work_id')";
$result = mysqli_query($db, $sql_statement);
header("Location: index.php");
?>