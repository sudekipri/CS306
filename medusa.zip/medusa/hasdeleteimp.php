<?php
include "config.php";

$report_no = $_POST['report_no'];
$sql_statement = "DELETE FROM has WHERE report_no = '$report_no'";
$result = mysqli_query($db, $sql_statement);
header ("Location: index.php");
?>