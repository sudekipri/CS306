<?php
include "config.php";


$dep_id = $_POST['dep_id'];
$sql_statement = "DELETE FROM departments WHERE dep_id = '$dep_id'";
$result = mysqli_query($db, $sql_statement);
header ("Location: index.php");
?>