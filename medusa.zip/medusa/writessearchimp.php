<!DOCTYPE html>
<html>
<head>
	<title></title>

<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>

</head>
<h1 style="color:white; font-family:calibri; ">M.E.D.U.S.A</h1>
<body style = "background-color: darkolivegreen; text-align: center;">

	

<div align="center">

	<table>


<tr> <th> Work ID </th> <th> Report No </th> </tr>



<?php

	include "config.php";

$raport_no2 = $_POST['raport_no'];

$sql_statement = "SELECT * FROM writes WHERE report_no = '$raport_no2'";

$result = mysqli_query($db, $sql_statement);

while ($row = mysqli_fetch_assoc($result))
{
	$work_id = $row['work_id'];
	$report_no = $row['report_no'];

	echo "<tr>" . "<th>".$work_id . "</th>" . "<th>".$report_no . "</th>" . "</tr>";
}

?>

</table>
<a style="color:white; font-family:calibri;" href = "http://localhost/medusa/">Return to main menu</a>
	</div>

	</body>
	</html>