<!DOCTYPE html>
<html>
<head>
	<title></title>

<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>

</head>
<h1 style="color:white; font-family:calibri; ">M.E.D.U.S.A</h1>
<body style = "background-color: darkolivegreen; text-align: center;">

<h2 style="color:white; font-family:calibri; ">Details of all departments are shown below</h2>

<div align="center">

	<table>

<tr> <th> Department ID </th> <th> Department Name </th> <th>Department Name</th> </tr> 

<?php

include "config.php";

$sql_statement = "SELECT * FROM departments";

$result = mysqli_query($db, $sql_statement);

while($row = mysqli_fetch_assoc($result))
{
  	$dep_id = $row['dep_id'];
  	$dep_name = $row['dep_name'];
	$manager = $row['manager'];
	
	echo "<tr>" . "<th>" . $dep_id . "</th>" . "<th>" . $dep_name . "</th>" . "<th>" . $manager . "</th>" . "</tr>";
}

?>

</table>
<a style="color:white; font-family:calibri;" href = "http://localhost/medusa/">Return to main menu</a>
</div>

</body>
</html>