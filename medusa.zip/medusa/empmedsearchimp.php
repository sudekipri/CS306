<!DOCTYPE html>
<html>
<head>
	<title></title>

<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>

</head>
<h1 style="color:white; font-family:calibri; ">M.E.D.U.S.A</h1>
<body style = "background-color: darkolivegreen; text-align: center;">

<h2 style="color:white; font-family:calibri; ">Medical reports and the department of the employee are shown below</h2>

<div align="center">

	<table>

<tr> <th> Employee Name </th> <th> Department Name </th> <th> Report No </th> <th> Date </th> <th> Treatment </th> <th> Medication </th> <th> Patient Name </th> </tr> 


<?php

include "config.php";

$work_id2 = $_POST['work_id'];

$sql_statement = "SELECT E.emp_name, D.dep_name, M.report_no, M.date, M.medication, M.treatment, P.patient_name FROM employees E, departments D, medical_reports M, writes W1, works_in W2, patients P, has H WHERE E.work_id = '$work_id2' AND E.work_id = W2.work_id AND W2.dep_id = D.dep_id AND E.work_id = W1.work_id AND W1.report_no = M.report_no AND M.report_no = H.report_no AND H.patient_id = P.patient_id";

$result = mysqli_query($db, $sql_statement);

while($row = mysqli_fetch_assoc($result))
{
  $emp_name = $row['emp_name'];
  $dep_name = $row['dep_name'];
  $report_no = $row['report_no'];
  $date = $row['date'];
  $treatment = $row['treatment'];
  $medication = $row['medication'];
  $patient_name = $row['patient_name'];



	echo "<tr>" . "<th>" . $emp_name . "</th>" . "<th>" . $dep_name . "</th>" . "<th>" . $report_no . "</th>" . "<th>" . $date . "</th>" . "<th>" . $treatment . "</th>" . "<th>" . $medication . "</th>" . "<th>" . $patient_name . "</th>" . "</tr>";
}

?>

</table>
<a style="color:white; font-family:calibri;" href = "http://localhost/medusa/">Return to main menu</a>
</div>

</body>
</html>