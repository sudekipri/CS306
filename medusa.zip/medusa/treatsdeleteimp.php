<?php
	include "config.php";


patient_id = $_POST['patient_id'];
$sql_statement = "DELETE FROM treats WHERE patient_id = '$patient_id'";
$result = mysqli_query($db, $sql_statement);
header("Location: index.php");
?>