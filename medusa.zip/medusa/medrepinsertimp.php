<?php
	include "config.php";


$raport_no = $_POST['raport_no'];
$date = $_POST['date'];
$medication = $_POST['medication'];
$treatment = $_POST['treatment'];
$bill = $_POST['bill'];
$sql_statement = "INSERT INTO medical_reports(report_no, date, medication, treatment, bill) VALUES ('$raport_no', '$date', '$medication', '$treatment', '$bill')";
$result = mysqli_query($db, $sql_statement);
header("Location: index.php");
?>