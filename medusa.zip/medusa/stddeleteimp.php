<?php
include "config.php";


$student_id = $_POST['student_id'];
$sql_statement = "DELETE FROM students WHERE student_id = '$student_id'";
$result = mysqli_query($db, $sql_statement);
header ("Location: index.php");
?>