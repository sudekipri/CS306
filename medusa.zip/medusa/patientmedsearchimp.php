<!DOCTYPE html>
<html>
<head>
	<title></title>

<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>

</head>
<h1 style="color:white; font-family:calibri; ">M.E.D.U.S.A</h1>
<body style = "background-color: darkolivegreen; text-align: center;">

<h2 style="color:white; font-family:calibri; ">Detailed medical past of the patient is shown below</h2>

<div align="center">

	<table>

<tr> <th> Patient Name </th> <th> Date </th> <th> Medication </th> <th> Treatment </th> <th> Bill </th><th> Doctor Name </th> </tr> 


<?php

include "config.php";

$patient_id2 = $_POST['patient_id'];

$sql_statement = "SELECT P.patient_name, M.date, M.medication, M.treatment, M.bill, E.emp_name  FROM patients P, has H, writes W, medical_reports M, employees E WHERE P.patient_id = '$patient_id2' AND P.patient_id = H.patient_id AND H.report_no = W.report_no AND W.work_id = E.work_id AND H.report_no = M.report_no";

$result = mysqli_query($db, $sql_statement);

while($row = mysqli_fetch_assoc($result))
{
    $patient_name = $row['patient_name'];
    $date = $row['date'];
    $medication = $row['medication'];
    $treatment = $row['treatment'];
    $bill = $row['bill'];
    $emp_name = $row['emp_name'];

	echo "<tr>" . "<th>" . $patient_name . "</th>" . "<th>" . $date . "</th>" .  "<th>" . $medication . "</th>" .  "<th>" . $treatment . "</th>" . "<th>" . $bill . "</th>" . "<th>" . $emp_name . "</th>" . " </tr>";
}

?>

</table>
<a style="color:white; font-family:calibri;" href = "http://localhost/medusa/">Return to main menu</a>
</div>

</body>
</html>