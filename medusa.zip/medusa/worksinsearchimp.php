<!DOCTYPE html>
<html>
<head>
	<title></title>

<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>

</head>
<h1 style="color:white; font-family:calibri; ">M.E.D.U.S.A</h1>
<body style = "background-color: darkolivegreen; text-align: center;">

<div align="center">

	<table>

<tr> <th> Department ID </th> <th> Work ID </th> </tr> 


<?php

include "config.php";

$work_id2 = $_POST['work_id'];

$sql_statement = "SELECT * FROM works_in WHERE work_id = '$work_id2'";

$result = mysqli_query($db, $sql_statement);

while($row = mysqli_fetch_assoc($result))
{
  $dep_id = $row['dep_id'];
  $work_id = $row['work_id'];

	echo "<tr>" . "<th>" . $dep_id . "</th>" . "<th>" . $work_id . "</th>" . "</tr>";
}

?>

</table>
<a style="color:white; font-family:calibri;" href = "http://localhost/medusa/">Return to main menu</a>
</div>

</body>
</html>