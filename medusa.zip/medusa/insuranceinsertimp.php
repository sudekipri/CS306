<?php
include "config.php";

$company_name = $_POST['company_name'];
$sql_statement = "INSERT INTO insurance(company_name) VALUES ('$company_name')";
$result = mysqli_query($db, $sql_statement);
header ("Location: index.php");
?>