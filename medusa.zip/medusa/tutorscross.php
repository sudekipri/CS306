<?php 

include "config.php";

$selection_id = $_POST['ids'];

if($selection_id == 1){header ("Location: tutorsinsert.php");}
if($selection_id == 2){header ("Location: tutorsdelete.php");}
if($selection_id == 3){header ("Location: tutorsprint.php");}
if($selection_id == 4){header ("Location: tutorssearch.php");}

?>