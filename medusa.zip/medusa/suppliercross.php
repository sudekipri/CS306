<?php 

include "config.php";

$selection_id = $_POST['ids'];

if($selection_id == 1){header ("Location: supplierinsert.php");}
if($selection_id == 2){header ("Location: supplierdelete.php");}
if($selection_id == 3){header ("Location: supplierprint.php");}
if($selection_id == 4){header ("Location: suppliersearch.php");}
if($selection_id == 5){header ("Location: supplierdepsearch.php");}

?>