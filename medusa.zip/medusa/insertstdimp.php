<?php
include "config.php";


$student_id = $_POST['student_id'];
$student_name = $_POST['student_name'];
$student_sex = $_POST['student_sex'];
$student_salary = $_POST['student_salary'];
$uni_name = $_POST['uni_name'];
$sql_statement = "INSERT INTO Students(student_id, student_name, student_sex, student_salary, uni_name) VALUES ('$student_id', '$student_name', '$student_sex', '$student_salary', 'uni_name')";
$result = mysqli_query($db, $sql_statement);
header ("Location: index.php");
?>