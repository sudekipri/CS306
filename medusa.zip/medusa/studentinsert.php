<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<h1 style="color:white; font-family:calibri; ">M.E.D.U.S.A</h1>
<body style = "background-color: darkolivegreen; text-align: center;">
	<h2 style="color:white; font-family:calibri; ">Please enter the information to create a new student</h2>
<form
	action="insertstdimp.php" method="POST">
	<h2 style="color:white; font-family:calibri; ">Student ID: <input type="number" id="fstd_id" name="student_id"> </h2>
	
	<h2 style="color:white; font-family:calibri; ">Name: <input type="text" id="fstd_name" name="student_name"> </h2>
	
	<h2 style="color:white; font-family:calibri; ">Sex(m/f): <input type="text" id="fstd_sex" name="student_sex"> </h2>
	
	<h2 style="color:white; font-family:calibri; ">Salary: <input type="number" id="fstd_salary" 
name="student_salary"> </h2>
	
	<h2 style="color:white; font-family:calibri; ">Uni Name: <input type="text" id="funiname" name="uni_name"> </h2>
	
	<input type="submit" value="Submit">
</form>
<a style="color:white; font-family:calibri;" href = "http://localhost/medusa/">Return to main menu</a>
</body>
</html>