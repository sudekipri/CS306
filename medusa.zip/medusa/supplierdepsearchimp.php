<!DOCTYPE html>
<html>
<head>
	<title></title>

<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>

</head>
<h1 style="color:white; font-family:calibri; ">M.E.D.U.S.A</h1>
<body style = "background-color: darkolivegreen; text-align: center;">

<h2 style="color:white; font-family:calibri; ">Details of the supplier and the department are shown below</h2>

<div align="center">

	<table>

<tr> <th> Supplier Name </th> <th> Supply Name </th> <th>Supply Date</th> <th>Quantity</th> <th>Unit Price</th> <th>Department</th> </tr> 


<?php

include "config.php";

$supplier_name2 = $_POST['supplier_name'];

$sql_statement = "SELECT S1.supplier_name, S1.supply_name, S1.supply_date, S1.quantity, S1.unit_price, D.dep_name FROM suppliers S1, supplies S2, departments D WHERE S1.supplier_name = '$supplier_name2' AND S1.supplier_name = S2.supplier_name AND S2.dep_id = D.dep_id";

$result = mysqli_query($db, $sql_statement);

while($row = mysqli_fetch_assoc($result))
{
  $supplier_name = $row['supplier_name'];
  $supply_name = $row['supply_name'];
	$supply_date = $row['supply_date'];
	$quantity = $row['quantity'];
	$unit_price = $row['unit_price'];
	$dep_name = $row['dep_name'];
	echo "<tr>" . "<th>" . $supplier_name . "</th>" . "<th>" . $supply_name . "</th>" . "<th>" . $supply_date . "</th>" . "<th>" . $quantity . "</th>" . "<th>" . $unit_price . "</th>" . "<th>" . $dep_name . "</th>" . "</tr>";
}

?>

</table>
<a style="color:white; font-family:calibri;" href = "http://localhost/medusa/">Return to main menu</a>
</div>

</body>
</html>