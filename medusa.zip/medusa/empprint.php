<!DOCTYPE html>
<html>
<head>
	<title></title>

<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>

</head>
<h1 style="color:white; font-family:calibri; ">M.E.D.U.S.A</h1>
<body style = "background-color: darkolivegreen; text-align: center;">

<h2 style="color:white; font-family:calibri; ">Details of all employees are shown below</h2>

<div align="center">

	<table>

<tr> <th> Work ID </th> <th> Name </th> <th>Age</th> <th>Sex</th> <th>Position</th> <th>Salary</th> </tr> 

<?php

include "config.php";

$sql_statement = "SELECT * FROM employees";

$result = mysqli_query($db, $sql_statement);

while($row = mysqli_fetch_assoc($result))
{
  	$work_id = $row['work_id'];
  	$emp_name = $row['emp_name'];
	$emp_age = $row['emp_age'];
	$emp_sex = $row['emp_sex'];
	$position = $row['position'];
	$emp_salary = $row['emp_salary'];

	echo "<tr>" . "<th>" . $work_id . "</th>" . "<th>" . $emp_name . "</th>" . "<th>" . $emp_age . "</th>" . "<th>" . $emp_sex . "</th>" . "<th>" . $position . "</th>" . "<th>" . $emp_salary . "</th>" . "</tr>";
}

?>

</table>
<a style="color:white; font-family:calibri;" href = "http://localhost/medusa/">Return to main menu</a>
</div>

</body>
</html>