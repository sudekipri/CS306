
<!DOCTYPE html>
<html>
<head>
	<title></title>

<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>

</head>
<h1 style="color:white; font-family:calibri; ">M.E.D.U.S.A</h1>
<body style = "background-color: darkolivegreen; text-align: center;">

<div align="center">

	<table>

<tr> <th> Supplier Name </th> <th> Department ID </th> </tr> 


<?php

include "config.php";

$supplies_name2 = $_POST['supplies_name'];
$dep_id2 = $_POST['dep_id'];

$sql_statement = "SELECT * FROM supplies S WHERE supplier_name = '$supplies_name2' and dep_id = '$dep_id2'";

$result = mysqli_query($db, $sql_statement);

while($row = mysqli_fetch_assoc($result))
{
  $supplies_name = $row['supplier_name'];
  $dep_id = $row['dep_id'];
	echo "<tr>" . "<th>" . $supplies_name . "</th>" . "<th>" . $dep_id . "</th>". "</tr>";
}

?>

</table>
<a style="color:white; font-family:calibri;" href = "http://localhost/medusa/">Return to main menu</a>
</div>

</body>
</html>
