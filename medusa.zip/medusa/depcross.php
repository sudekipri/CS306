<?php 

include "config.php";

$selection_id = $_POST['ids'];

if($selection_id == 1){header ("Location: depinsert.php");}
if($selection_id == 2){header ("Location: depdelete.php");}
if($selection_id == 3){header ("Location: depprint.php");}
if($selection_id == 4){header ("Location: depidsearch.php");}

?>