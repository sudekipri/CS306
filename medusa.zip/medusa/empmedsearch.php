<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<h1 style="color:white; font-family:calibri; ">M.E.D.U.S.A</h1>
<body style = "background-color: darkolivegreen; text-align: center;">
	<h2 style="color:white; font-family:calibri; ">Please enter the ID of an employee to search his/her medical reports and department</h2>
<form
	action="empmedsearchimp.php" method="POST">
	<h2 style="color:white; font-family:calibri; ">Work ID: <input type="number" id="fwork_id" name="work_id"> </h2>
	
	<input type="submit" value="Submit">
</form>
<a style="color:white; font-family:calibri;" href = "http://localhost/medusa/">Return to main menu</a>
</body>
</html>