<?php
include "config.php";

$supplier_name = $_POST['supplier_name'];
$dep_id = $_POST['dep_id'];
$sql_statement = "DELETE FROM supplies WHERE supplier_name = '$supplier_name' and dep_id = '$dep_id'";

$result = mysqli_query($db, $sql_statement);
header ("Location: index.php");
?>