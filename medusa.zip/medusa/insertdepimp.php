<?php
include "config.php";


$dep_id = $_POST['dep_id'];
$dep_name = $_POST['dep_name'];
$manager = $_POST['manager'];
$sql_statement = "INSERT INTO departments(dep_id, dep_name, manager) VALUES ('$dep_id', '$dep_name', '$manager')";
$result = mysqli_query($db, $sql_statement);
header ("Location: index.php");
?>