<?php
include "config.php";

$company_name = $_POST['company_name'];
$sql_statement = "DELETE FROM insurance WHERE company_name = '$company_name'";
$result = mysqli_query($db, $sql_statement);
header ("Location: index.php");
?>