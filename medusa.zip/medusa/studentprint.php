<!DOCTYPE html>
<html>
<head>
	<title></title>

<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>

</head>
<h1 style="color:white; font-family:calibri; ">M.E.D.U.S.A</h1>
<body style = "background-color: darkolivegreen; text-align: center;">

<h2 style="color:white; font-family:calibri; ">Details of all students are shown below</h2>

<div align="center">

	<table>

<tr> <th> Student ID </th> <th> Name </th> <th>Sex</th> <th>Salary</th> <th>Uni Name</th> </tr> 

<?php

include "config.php";

$sql_statement = "SELECT * FROM students";

$result = mysqli_query($db, $sql_statement);

while($row = mysqli_fetch_assoc($result))
{
  	$student_id = $row['student_id'];
  	$student_name = $row['student_name'];
	$student_sex = $row['student_sex'];
	$uni_name = $row['uni_name'];
	$student_salary = $row['student_salary'];

	echo "<tr>" . "<th>" . $student_id . "</th>" . "<th>" . $student_name . "</th>" . "<th>" . $student_sex . "</th>" . "<th>" . $student_salary . "</th>" . "<th>" . $uni_name . "</th>" . "</tr>";
}

?>

</table>
<a style="color:white; font-family:calibri;" href = "http://localhost/medusa/">Return to main menu</a>
</div>

</body>
</html>