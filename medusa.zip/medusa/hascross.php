<?php 

include "config.php";

$selection_id = $_POST['ids'];

if($selection_id == 1){header ("Location: hasinsert.php");}
if($selection_id == 2){header ("Location: hasdelete.php");}
if($selection_id == 3){header ("Location: hasprint.php");}
if($selection_id == 4){header ("Location: hassearch.php");}

?>