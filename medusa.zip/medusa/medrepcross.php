<?php 

include "config.php";

$selection_id = $_POST['ids'];

if($selection_id == 1){header ("Location: medrepinsert.php");}
if($selection_id == 2){header ("Location: medrepdelete.php");}
if($selection_id == 3){header ("Location: medrepprint.php");}
if($selection_id == 4){header ("Location: medrepsearch.php");}

?>